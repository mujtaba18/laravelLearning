<!DOCTYPE html>
<html>
<head>
    <title>Laravel Learning</title>
</head>
<body>
    <h1>Welcome</h1>

    <!-- <ul>
        <li><a href="/">Welcome</a></li>
        <li><a href="about">About</a></li>
    </ul> -->

    <ul>
        
        @foreach ($tasks as $task)
        	<li>
                <a href='/tasks/{{ $task->id }}'>{{ $task->body }}</a>
            </li>
        @endforeach

    </ul>

</body>
</html>