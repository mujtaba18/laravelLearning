<!DOCTYPE html>
<html>
<head>
	<title>Tasks</title>
</head>
<body>
	{{ $task->body }}
</body>
</html>