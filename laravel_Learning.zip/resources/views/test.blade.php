<!DOCTYPE html>
<html>
    <head>
        <title>Image Calling</title>
    </head>
    <body>
        <h1>Image Calling</h1>
        <div id="imageURL" style="width: 80%; margin: 0 auto;">

        </div>
        <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
        <script>

            var API_KEY = '7528902-4e3435e1f4e7d0fb61578b1a3';
            var URL = "https://pixabay.com/api/?key="+API_KEY+"&q="+encodeURIComponent('flower')+"&pretty=true";
            var totalImage = 0;
            var response   = '';
            $.getJSON(URL, function(data){
                if (parseInt(data.totalHits) > 0){
                    response = $.each(data.hits, function(i, hit){
                        hit.userImageURL;
                        //totalImage++;
                        //$("#imageURL").append('<div"'+i+'" style="float:left;width:250px; padding-left:5px;"><img src="'+hit.userImageURL+'"></div>');
                    });
                    for (var i = 0; i < response.length; i++) {
                        $("#imageURL").append('<div"'+i+'" style="float:left;width:250px; padding-left:5px;"><img src="'+response[i].userImageURL+'"></div>')
                    }
                }

                else{
                    console.log('No hits');
                }
            });

        </script>
    </body>
</html>
