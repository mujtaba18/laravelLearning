@include('layout.header')
    
    @include('layout.nav')

    
    @yield('content')
    @yield('sidebar')


@include('layout.footer')