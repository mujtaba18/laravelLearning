<div class="blog-masthead">
  <div class="container">
    <nav class="nav blog-nav">
      <a class="nav-link active" href="/">Home</a>
      <a class="nav-link" href="/login">Login</a>
      <a class="nav-link" href="/posts/create">Create a Post</a>
      <a class="nav-link" href="/register">Get Register</a>

      @if(Auth::check())
      	<a class="nav-link ml-auto" href="/logout">Welcome: <i>{{Auth::user()->name}}</i></a>
      @endif
    </nav>
  </div>
</div>

@if($flash = session('message'))
  <div class="alert alert-success">
    {{$flash}}
  </div>
@endif