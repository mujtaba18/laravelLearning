<!DOCTYPE html>
<html>
<head>
    <title>Laravel Learning</title>
</head>
<body>
    <h1>Welcome</h1>
<div id=""></div>
    <!-- <ul>
        <li><a href="/">Welcome</a></li>
        <li><a href="about">About</a></li>
    </ul> -->

    <ul>

        @foreach ($tasks as $task)
        	<li>{{ $task->body }}</li>
        @endforeach

    </ul>

</body>
</html>
