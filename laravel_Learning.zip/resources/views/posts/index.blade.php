@extends('layout.master')
@section('content')

    <div class="blog-header">
      <div class="container">
        <h1 class="blog-title">My Blog</h1>
        <p class="lead blog-description">I should Start Blogging.</p>
      </div>
    </div>

    <div class="container">

      <div class="row">

        <div class="col-sm-8 blog-main">
            @foreach($posts as $post)
              @include('posts.post')
            @endforeach
            <nav aria-label="Page navigation example">
              {!! $posts->links() !!}
            </nav>
        </div><!-- /.blog-main -->

@endsection
@include('layout.sidebar')
