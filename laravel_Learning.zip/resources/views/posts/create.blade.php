@extends('layout.master')

@section('content')

	<div class="blog-header">
      <div class="container">
        <h1 class="blog-title">The Bootstrap Blog</h1>
        <p class="lead blog-description">An example blog template built with Bootstrap.</p>
      </div>
    </div>

    <div class="container">

      <div class="row">
		<div class="col-sm-8 blog-main">
			
			<h1>Create A Post</h1>
			<hr>

			<form method="POST" action="/posts">
				{{ csrf_field() }}

				  <div class="form-group">
				    <label for="title">Post Title</label>
				    <input type="text" class="form-control" id="title" name="title">
				  </div>

				  <div class="form-group">
				    <label for="body">Body</label>
				    <textarea class="form-control" id="body" name="body"></textarea>
				  </div>

				  <div class="form-group">
				  	<button type="submit" class="btn btn-primary">Publish</button>
				  </div>

				  @include('layout.errors')


			</form>

		</div>

@endsection
@include('layout.sidebar')