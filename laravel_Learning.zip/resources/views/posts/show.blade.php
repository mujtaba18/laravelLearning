@extends('layout.master')
@section('content')

	<div class="blog-header">
      <div class="container">
        <h1 class="blog-title">My Blog</h1>
        <p class="lead blog-description">I should start Blogging</p>
      </div>
    </div>

    <div class="container">

      <div class="row">

        <div class="col-sm-8 blog-main">

          <div class="blog-post">
            <h2 class="blog-post-title">
              <a href="/posts/{{ $post->id }}"> {{ $post->title }} </a></h2>
            <p class="blog-post-meta">{{ $post->created_at->toFormattedDateString() }}</p>
              @if(count($post->tags))
                <ul>
                  @foreach($post->tags as $tag)
                    <li>
                      <a href="/posts/tags/{{ $tag->name }}">
                        {{ $tag->name }}
                      </a>
                    </li>
                  @endforeach
                </ul>
              @endif
            <p>{{$post->body}}</p>
          </div><!-- /.blog-post -->
          <div class="comments">
            <ul class="list-group">
              @foreach($post->comments as $posts)

                <li class="list-group-item">
                  <strong>{{ $posts->created_at->diffForHumans() }}: &nbsp;</strong>
                  {{ $posts->body }}
                </li>

              @endforeach
            </ul>
          </div>

          <hr>

          <div class="comments">
            
            <form method="POST" action="/posts/{{ $post->id }}/comments">
              
              {{ csrf_field() }}

              <div class="form-group">
                <label for="body">Your Comment</label>
                <textarea class="form-control" id="body" name="body"></textarea>
              </div>

              <div class="form-group">
                <button type="submit" class="btn btn-primary">Add Comment</button>
              </div>

              @include('layout.errors')

            </form>

          </div>
          

        </div>

@endsection
@include('layout.sidebar')