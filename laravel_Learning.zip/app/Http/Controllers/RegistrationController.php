<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Requests\RegistrationForm;

class RegistrationController extends Controller
{
    public function create()
    {
        return view('registrations.create');
    }

    public function store(RegistrationForm $request)
    {
        $request->userGetRegister();

        session()->flash('message', 'Thankyou For Registering here.');


        // $this->validate(request(),[

        //  'name'      => 'required',
        //  'email'     => 'required|email',
        //  'password'  => 'required|confirmed'

        // ]);

        // $user = User::create([

        //        'name' => request('name'),
        //        'email'=>request('email'),
        //        'password'=>bcrypt(request('password'))

        //        //'name','email','password'

        //    ]);

        // auth()->login($user);

        return redirect('/');
    }
}
