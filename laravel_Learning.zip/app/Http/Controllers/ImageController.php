<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use GuzzleHttp\Client;
use GuzzleHttp\Message\Response;
use App\APICall;

class ImageController extends Controller
{
    public function index()
    {
        $client = new \GuzzleHttp\Client();
        $res = $client->request('GET','https://pixabay.com/api/?key=7528902-4e3435e1f4e7d0fb61578b1a3&q=beautiful&pretty=true');
        $res = json_decode($res->getBody()->getContents(),true);



        //$url = "https://pixabay.com/api/?key=7528902-4e3435e1f4e7d0fb61578b1a3&q=beautiful&pretty=true";
        //$res = file_get_contents($url);
        //$res = json_decode($res);
        //$res = $res->paginate(3);
        return view('imageShow',compact('res'));//->with('res',json_decode($res,true));
    }
}
