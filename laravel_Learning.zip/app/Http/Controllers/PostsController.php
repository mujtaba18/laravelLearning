<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Posts;
use App\Repositories\Post;

use Carbon\Carbon;

class PostsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['index','show']);
    }
    public function index()
    {
        //$posts = Posts::all();
        //$posts = Posts::latest()->get();

        if (request(['month','year']) != null) {
            $posts = Posts::latest()
                            ->filter(request(['month','year']))
                            ->paginate(1);
        } else {
            $posts = Posts::latest()->paginate(1);
            //$posts = Posts::paginate(1);
            //$posts = $post->all();
        }

        return view('posts.index', compact('posts'));
    }
    public function show(Posts $post)
    {
        return view('posts.show', compact('post'));
    }
    public function create()
    {
        return view('posts.create');
    }
    public function store()
    {
        //$post = new Posts;

        // $post->title = request('title');
        // $post->body  = request('body');

        // $post->save();

        // Posts::create([

        //  'title' => request('title'),
        //  'body'  => request('body')

        // ]);

        $this->validate(request(), [

            'title' => 'required',
            'body'  => 'required'

        ]);

        //Posts::create(request(['title','body','user_id']));

        auth()->user()->publish(

            new Posts(request(['title','body']))

        );

        session()->flash('message', 'Your Post has now been Published!');

        // Posts::create([

        //     'title'     => request('title'),
        //     'body'      => request('body'),
        //     'user_id'   => auth()->id() //'user_id' =>auth()->user()->id

        // ]);

        //return view('posts.index');

        return redirect('/');
    }
}
