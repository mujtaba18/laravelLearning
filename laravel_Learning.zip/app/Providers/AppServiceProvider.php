<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer('layout.sidebar',function($view){

            //second method like making a variable and pass it with array view method like below
            $archives = \App\Posts::archives();
            $tags = \App\Tag::has('posts')->pluck('name');

            $view->with(compact('archives','tags'));

            //First Method like this below
            //$view->with('archives',\App\Posts::archives());
            //$view->with('tags',\App\Tag::has('posts')->pluck('name'));

        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
