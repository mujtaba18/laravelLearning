<?php

namespace App\Repositories;

use App\Posts;

class Post{
	
	public function all()
	{
		return Posts::all();
	}

}