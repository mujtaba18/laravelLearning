<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // return view('welcome',[
    // 	'name' => 'Mujtaba'
    // ]);
    //return view('welcome')->with('name','mujtaba');

    //$name = 'Mujtaba';
    //return view('welcome',compact('name'));

    // $tasks = [
    // 	'Task # 1',
    // 	'Task # 2',
    // 	'Task # 3'
    // ];

    $tasks = DB::table('tasks')->get();
    return view('welcome',compact('tasks'));
});
Route::get('/tasks', function () {

    //$tasks = DB::table('tasks')->get();

    $tasks = App\Task::all();
    return view('task.index',compact('tasks'));
});
Route::get('/tasks/{task}', function ($id) {
    
    //$task = DB::table('tasks')->find($id);

    $task = App\Task::find($id);
    return view('task.show',compact('task'));

});
Route::get('/about',function(){
	return view('about');
});
