<?php $__env->startSection('content'); ?>

	<div class="blog-header">
      <div class="container">
        <h1 class="blog-title">My Blog</h1>
        <p class="lead blog-description">I should start Blogging</p>
      </div>
    </div>

    <div class="container">

      <div class="row">

        <div class="col-sm-8 blog-main">

          <div class="blog-post">
            <h2 class="blog-post-title">
              <a href="/posts/<?php echo e($post->id); ?>"> <?php echo e($post->title); ?> </a></h2>
            <p class="blog-post-meta"><?php echo e($post->created_at->toFormattedDateString()); ?></p>
              <?php if(count($post->tags)): ?>
                <ul>
                  <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                      <a href="/posts/tags/<?php echo e($tag->name); ?>">
                        <?php echo e($tag->name); ?>

                      </a>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              <?php endif; ?>
            <p><?php echo e($post->body); ?></p>
          </div><!-- /.blog-post -->
          <div class="comments">
            <ul class="list-group">
              <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li class="list-group-item">
                  <strong><?php echo e($posts->created_at->diffForHumans()); ?>: &nbsp;</strong>
                  <?php echo e($posts->body); ?>

                </li>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>

          <hr>

          <div class="comments">
            
            <form method="POST" action="/posts/<?php echo e($post->id); ?>/comments">
              
              <?php echo e(csrf_field()); ?>


              <div class="form-group">
                <label for="body">Your Comment</label>
                <textarea class="form-control" id="body" name="body"></textarea>
              </div>

              <div class="form-group">
                <button type="submit" class="btn btn-primary">Add Comment</button>
              </div>

              <?php echo $__env->make('layout.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </form>

          </div>
          

        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>