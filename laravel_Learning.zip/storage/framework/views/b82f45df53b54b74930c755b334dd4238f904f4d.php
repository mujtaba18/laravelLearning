<?php $__env->startSection('content'); ?>

    <div class="blog-header">
      <div class="container">
        <h1 class="blog-title">My Blog</h1>
        <p class="lead blog-description">I should Start Blogging.</p>
      </div>
    </div>

    <div class="container">

      <div class="row">

        <div class="col-sm-8 blog-main">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo $__env->make('posts.post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <nav aria-label="Page navigation example">
              <?php echo $posts->links(); ?>

            </nav>
        </div><!-- /.blog-main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>