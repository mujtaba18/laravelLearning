<?php echo e($res); ?>

