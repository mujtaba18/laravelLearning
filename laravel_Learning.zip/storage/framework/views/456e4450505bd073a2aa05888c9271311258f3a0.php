<!DOCTYPE html>
<html>
<head>
    <title>Laravel Learning</title>
</head>
<body>
    <h1>Welcome</h1>

    <!-- <ul>
        <li><a href="/">Welcome</a></li>
        <li><a href="about">About</a></li>
    </ul> -->

    <ul>
        
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	<li>
                <a href='/tasks/<?php echo e($task->id); ?>'><?php echo e($task->body); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>

</body>
</html>