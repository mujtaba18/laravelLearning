<div class="blog-masthead">
  <div class="container">
    <nav class="nav blog-nav">
      <a class="nav-link active" href="/">Home</a>
      <a class="nav-link" href="/login">Login</a>
      <a class="nav-link" href="/posts/create">Create a Post</a>
      <a class="nav-link" href="/register">Get Register</a>

      <?php if(Auth::check()): ?>
      	<a class="nav-link ml-auto" href="/logout">Welcome: <i><?php echo e(Auth::user()->name); ?></i></a>
      <?php endif; ?>
    </nav>
  </div>
</div>

<?php if($flash = session('message')): ?>
  <div class="alert alert-success">
    <?php echo e($flash); ?>

  </div>
<?php endif; ?>