<?php $__env->startSection('content'); ?>

    <div class="blog-header">
      <div class="container">
        <h1 class="blog-title">My Blog</h1>
        <p class="lead blog-description">I should Start Blogging.</p>
      </div>
    </div>

    <div class="container">

      <div class="row">

        <div class="col-sm-8 blog-main">

                <?php $__currentLoopData = $res->hits->pageURL; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($hit); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><!-- /.blog-main -->

<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
    //allImage();
    function allImage(){
        var API_KEY = '7528902-4e3435e1f4e7d0fb61578b1a3';
        var URL = "https://pixabay.com/api/?key="+API_KEY+"&q="+encodeURIComponent('pretty')+"&pretty=true";
        var totalImage = 0;
        var response   = '';
        $.getJSON(URL, function(data){
            if (parseInt(data.totalHits) > 0){
                response = $.each(data.hits, function(i, hit){
                    hit.userImageURL;
                    //totalImage++;
                    //$("#imageURL").append('<div"'+i+'" style="float:left;width:250px; padding-left:5px;"><img src="'+hit.userImageURL+'"></div>');
                });
                for (var i = 0; i < response.length; i++) {
                    $("#imageURL").append('<div"'+i+'" class="col-sm-2"><img src="'+response[i].userImageURL+'"></div>')
                }
            }

            else{
                console.log('No hits');
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>