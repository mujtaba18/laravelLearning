<!DOCTYPE html>
<html>
<head>
	<title>Learning Laravel</title>
</head>
<body>
	<h1>About</h1>

	<ul>
        <li><a href="/">Welcome</a></li>
        <li><a href="about">About</a></li>
    </ul>

</body>
</html>