<?php $__env->startSection('content'); ?>

	

    <div class="container">

      <div class="row">
		<div class="col-sm-8 blog-main">
			
			<h1>Sign In</h1>
			<hr>

			<form method="POST" action="/login">
				<?php echo e(csrf_field()); ?>


				  

				  <div class="form-group">
				    <label for="email">Email</label>
				    <input type="email" class="form-control" id="email" name="email">
				  </div>

				  <div class="form-group">
				    <label for="password">Password</label>
				    <input type="password" class="form-control" id="password" name="password">
				  </div>

				  <div class="form-group">
				  	<button type="submit" class="btn btn-primary">Register</button>
				  </div>

				  <?php echo $__env->make('layout.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


			</form>

		</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>