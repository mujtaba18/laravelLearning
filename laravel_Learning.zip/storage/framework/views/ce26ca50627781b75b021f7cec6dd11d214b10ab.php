<!DOCTYPE html>
<html>
<head>
	<title>Tasks</title>
</head>
<body>
	<?php echo e($task->body); ?>

</body>
</html>